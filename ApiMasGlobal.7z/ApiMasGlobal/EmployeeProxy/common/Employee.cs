﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeProxy.common
{
    public class Employee: ApiEmployees.Employee
    {
        public decimal AnnualSalary { get; set; }
    }
}
