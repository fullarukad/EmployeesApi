﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeProxy.common
{
    public class ResponseObject
    {
        public List<Employee> listEmploye { get; set; }
        public string error { get; set; }
    }
}
