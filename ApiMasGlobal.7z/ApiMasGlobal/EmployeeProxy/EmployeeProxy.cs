﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ApiEmployees;

namespace EmployeeProxy
{
    public class EmployeeProxy
    {
        string endpoint = "http://masglobaltestapi.azurewebsites.net/api/Employees";
        string error = string.Empty;
        common.ResponseObject response = null;
        List<Employee> listEmployee;
        public common.ResponseObject getlistEmployee()
        {
            getServiceData();
            this.response = new common.ResponseObject();
            this.response.listEmploye = new List<common.Employee>();
            common.Employee commonemploye = null;

            if (error != "")
            {
                this.response.error = "error getting response from employees service";
            }
            else
            {
                foreach (Employee employee in listEmployee)
                {
                    commonemploye = new common.Employee();

                    commonemploye.id = employee.id;
                    commonemploye.name = employee.name;
                    commonemploye.roleName = employee.roleName;
                    commonemploye.roleId = employee.roleId;
                    commonemploye.roleDescription = employee.roleDescription;
                    commonemploye.monthlySalary = employee.monthlySalary;
                    commonemploye.hourlySalary = employee.hourlySalary;
                    commonemploye.contractTypeName = employee.contractTypeName;
                    
                    commonemploye.AnnualSalary = calculatedAnnualSalary(employee);

                    this.response.listEmploye.Add(commonemploye);
                }           
                
            }

            return this.response;
        }

        public common.ResponseObject getEmployeeByID(int id)
        {
            getServiceData();
            this.response = new common.ResponseObject();
            this.response.listEmploye = new List<common.Employee>();
            common.Employee commonemploye = null;

            if (error != "")
            {
                this.response.error = "error getting response from employees service";
            }
            else
            {
                foreach (Employee employee in listEmployee)
                {
                    if (employee.id == id)
                    {
                        commonemploye = new common.Employee();
                        commonemploye.id = employee.id;
                        commonemploye.name = employee.name;
                        commonemploye.roleName = employee.roleName;
                        commonemploye.roleId = employee.roleId;
                        commonemploye.roleDescription = employee.roleDescription;
                        commonemploye.monthlySalary = employee.monthlySalary;
                        commonemploye.hourlySalary = employee.hourlySalary;
                        commonemploye.contractTypeName = employee.contractTypeName;

                        commonemploye.AnnualSalary = calculatedAnnualSalary(employee);

                        this.response.listEmploye.Add(commonemploye);
                    }                    
                }
            }
            return this.response;
        }

        public decimal calculatedAnnualSalary(Employee employee)
        {
            decimal salary=0;

            if(employee.contractTypeName== "HourlySalaryEmployee")
            {
                salary = 120 * employee.hourlySalary * 12;
            }

            if(employee.contractTypeName == "MonthlySalaryEmployee")
            {
                salary = employee.monthlySalary * 12;
            }

            return salary;
        }

        public void getServiceData()
        {
            EmployeesApi api = new EmployeesApi(endpoint);
            listEmployee = new List<Employee>();
            listEmployee = api.getEmployees(out error);
        }
    }
}
