﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ApiEmployees
{
    public class EmployeesApi
    {
        string Endpoint = "";        
        public EmployeesApi(string Endpoint)
        {
            this.Endpoint = Endpoint;
        }

        public List<Employee> getEmployees(out string error)
        {     
            string response = String.Empty;
            List<Employee> listresponse = new List<Employee>();
            error = "";
            try
            {
                using (var client = new WebClient())
                {
                    response = client.DownloadString(Endpoint);
                }

                if(response != null && response != "")
                {
                    listresponse = JsonConvert.DeserializeObject<List<Employee>>(response);
                }
            }
            catch (Exception ex)
            {
                error = ex.Message;
            }
            return listresponse;
        }
    }
}
