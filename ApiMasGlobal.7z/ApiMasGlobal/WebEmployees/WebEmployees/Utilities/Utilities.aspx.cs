﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using EmployeeApi = EmployeeProxy.EmployeeProxy;
using ResponseObject = EmployeeProxy.common.ResponseObject;

namespace WebEmployees.Utilities
{
    public partial class Utilities : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        [WebMethod(EnableSession = false)]
        public static string gettemplate()
        {
            string template = "";

            template = Global.loadTemplate();

            return template;
        }


        [WebMethod(EnableSession = false)]
        public static string getInfoEmployee(string id)
        {
            EmployeeApi proxy = new EmployeeApi();
            int idemployee = Int32.Parse(id);
            ResponseObject response = new ResponseObject();
            if (idemployee == 0)
            {
                response = proxy.getlistEmployee();
            }
            else
            {
                response = proxy.getEmployeeByID(idemployee);
            }

            return JsonConvert.SerializeObject(response);
        }
    }
}