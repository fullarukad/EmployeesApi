﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Optimization;
using System.Web.Routing;
using System.Web.Security;
using System.Web.SessionState;
using System.Web.UI;

namespace WebEmployees
{
    public class Global : HttpApplication
    {
        void Application_Start(object sender, EventArgs e)
        {
            // Code that runs on application startup
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            ScriptResourceDefinition myScriptResDef = new ScriptResourceDefinition();
            myScriptResDef.Path = "~/Scripts/jquery-jtemplates.js";
            myScriptResDef.DebugPath = "~/Scripts/jquery-jtemplates.js";
            myScriptResDef.CdnPath = "";
            myScriptResDef.CdnDebugPath = "";
            ScriptManager.ScriptResourceMapping.AddDefinition("jtemplates", null, myScriptResDef);

            myScriptResDef = new ScriptResourceDefinition();
            myScriptResDef.Path = "~/Scripts/jquery.json.min.js";
            myScriptResDef.DebugPath = "~/Scripts/jquery.json.min.js";
            myScriptResDef.CdnPath = "";
            myScriptResDef.CdnDebugPath = "";
            ScriptManager.ScriptResourceMapping.AddDefinition("json", null, myScriptResDef);
        }

        public static string loadTemplate()
        {
            string archivo = System.Web.HttpContext.Current.Server.MapPath(@"~/Templates/FormAccess.html");
            string res = "";
            if (File.Exists(archivo))
            {
                StreamReader fArchivo = File.OpenText(archivo);
                res = fArchivo.ReadToEnd();
                fArchivo.Close();
            }
            return res;
        }
    }
}