﻿

function init() {

    var id = $("#idEmployee").val();

    if (id == "") {
        id = "0";
    }

    $.ajax({
        type: "POST",
        url: "./Utilities/Utilities.aspx/getInfoEmployee",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,        
        data: "{id:" + id + "}",
        error: function (x, t, m) {

            if (t === "timeout") {
                return "";
            } else {
                return "";
            }
        },
        success: function (res) {

            var obj = $.evalJSON(res.d);

            $("#display").setTemplate(getTemplate());
            $("#display").processTemplate(obj);
            $("#display").show();

        }
    });   

}

function getTemplate() {
    var Tres = "";
    $.ajax({
        type: "POST",
        url: "./Utilities/Utilities.aspx/gettemplate",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        error: function (x, t, m) {

            if (t === "timeout") {
                return "";
            } else {
                return "";
            }
        },
        success: function (res) {
            Tres = res.d;
        }
    });

    return Tres;
}